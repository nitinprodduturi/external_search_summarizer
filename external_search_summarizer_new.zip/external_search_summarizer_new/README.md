# GenAI Search Component

A powerful Python component that combines Large Language Models (LLMs) with advanced web search capabilities to provide intelligent content discovery, extraction, and summarization with **high-quality results**.

## ✨ Enhanced Features

- **🔍 Intelligent Search Term Generation**: LLM-powered search term optimization for better coverage
- **🌐 Multi-Source Web Search**: Google SerpAPI integration with configurable result limits
- **📄 Advanced Content Extraction**: Robust content extraction with quality validation
- **🎯 Smart Relevance Scoring**: LLM-based relevance evaluation with content quality filtering
- **📝 Comprehensive Summarization**: AI-generated summaries with proper source citations
- **📊 Professional Export Options**: Excel and Markdown export with enhanced formatting
- **⚡ Performance Optimized**: Configurable timeouts, parallel processing, and result limits
- **🛡️ Quality Assurance**: Automatic filtering of low-quality, promotional, and navigation content

## 🚀 Recent Improvements

### Enhanced Search Results
- **Increased URL Coverage**: Now generates 15-25 URLs instead of just 5
- **Better Content Quality**: Automatic filtering of promotional and navigation content
- **Improved Relevance Scoring**: More realistic scoring with content quality validation
- **Robust Content Extraction**: Multiple fallback strategies for modern websites

### Performance Optimizations
- **Configurable Result Limits**: Up to 50 search results with 20 per search term
- **Smart Content Filtering**: Pre-validation of content quality before LLM processing
- **Efficient Processing**: Optimized timeouts and parallel content extraction

### Quality Assurance
- **Content Length Validation**: Filters out very short content automatically
- **Source Authority Assessment**: Recognizes academic and technical domains
- **Spam Detection**: Identifies promotional and low-quality content
- **Structure Analysis**: Evaluates content organization and readability

## Quick Start

### 1. Setup Environment

```bash
# Create virtual environment
python -m venv .venv

# Activate virtual environment
# On macOS/Linux:
source .venv/bin/activate
# On Windows:
# .venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### Environment Variables

Create a `.env` file in your project root:

```env
# Required: Google Generative AI API key (for LLM functionality)
GOOGLE_API_KEY=your_google_api_key_here

# Required: SerpAPI key (for Google search engine)
SERPAPI_API_KEY=your_serpapi_key_here

# Optional: Azure OpenAI (alternative to Google AI)
AZURE_OPENAI_API_KEY=your_azure_openai_api_key_here
AZURE_OPENAI_ENDPOINT=your_azure_openai_endpoint_here
AZURE_OPENAI_DEPLOYMENT_NAME=your_deployment_name_here
```

**Note**: Google search engine is now recommended for better results and reliability!

### 3. Run the Application

```bash
# Run with default query
python main.py

# Run with custom query
python main.py "your search query here"
```

## Usage Examples

### Basic Usage

```python
from genai_search import create_genai_component

# Create component with optimized settings
component = create_genai_component(
    llm_provider="google",
    search_engine="google",  # Recommended for best results
    max_search_results=50,   # Increased from 25
    relevance_threshold=0.3
)

# Process a query
results = component.process_query("What are the latest developments in quantum computing?")

# Get the summary
print(results.summary)

# Clean up
component.close()
```

### Search Engine Options

The component supports multiple search engines:

#### 🔍 Google Search (Recommended)
```python
# Best results and reliability
component = create_genai_component(
    llm_provider="google",
    search_engine="google",  # High-quality results, 15-25 URLs
    config=config
)
```

#### 🦆 DuckDuckGo (Alternative)
```python
# Free, no API key required
component = create_genai_component(
    llm_provider="google",
    search_engine="duckduckgo",  # Limited results, 5-10 URLs
    config=config
)
```

**Advantages:**
- ✅ No API key required
- ✅ Free to use
- ✅ Privacy-focused
- ✅ No rate limits
- ✅ Perfect for development/testing

**Disadvantages:**
- ❌ Limited results
- ❌ Less metadata
- ❌ May have fewer results

#### 🔍 Google Search (SerpAPI)
```python
# Requires SerpAPI key
component = create_genai_component(
    llm_provider="google",
    search_engine="google",  # Requires SERPAPI_API_KEY
    config=config
)
```

**Advantages:**
- ✅ High-quality results
- ✅ Rich metadata
- ✅ More comprehensive results

**Disadvantages:**
- ❌ Requires API key
- ❌ Rate limits and costs
- ❌ Dependency on external service

### Azure OpenAI Usage

```python
from genai_search import create_genai_component

# Create component with Azure OpenAI
component = create_genai_component(
    llm_provider="azure",
    azure_openai_api_key="your_azure_api_key",
    azure_openai_endpoint="your_azure_endpoint",
    azure_openai_deployment_name="your_deployment_name",
    serpapi_api_key="your_serpapi_key"
)

# Process a query
results = component.process_query("What are the best cybersecurity practices for 2024?")

print(results.summary)
component.close()
```

### Export Results

```python
from genai_search.exporters import ExcelExporter

# Export to Excel with enhanced styling
exporter = ExcelExporter(output_dir="runs")
xlsx_path = exporter.export(
    user_query=query,
    config=config_dict,
    search_terms=search_terms_dict,
    search_results=results.search_results,
    extracted_contents=results.extracted_contents,
    summary=results.summary,  # Now includes source citations
    statistics=results.statistics.__dict__
)
```

## Configuration Options

### ComponentConfig Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `max_search_results` | int | **50** | Maximum search results to process (increased from 25) |
| `max_content_length` | int | 2000 | Maximum content length to extract |
| `relevance_threshold` | float | 0.5 | Minimum relevance score threshold (improved) |
| `headless_browser` | bool | True | Run browser in headless mode |
| `search_delay` | float | 0.5 | Delay between searches |
| `page_load_timeout` | int | 10 | Page load timeout in seconds |
| `llm_temperature` | float | 0.3 | LLM temperature for generation |
| `llm_max_tokens` | int | 2048 | Maximum tokens for LLM output |

### Current Performance Metrics

With the latest improvements, the system now provides:

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| **Search Results** | 4-5 URLs | 15-25 URLs | **4-5x increase** |
| **Extracted Content** | 3-4 articles | 10-20 articles | **3-5x increase** |
| **Content Quality** | Mixed quality | High quality | **Significantly improved** |
| **Relevance Scoring** | Inconsistent | Realistic | **More accurate** |
| **Processing Time** | 50-60s | 70-120s | **Reasonable for more content** |

### Search Term Generation

The system now generates **10 search terms** (increased from 5) and gets **up to 20 results per term**:

```python
# Search term generation
search_terms = [
    "artificial intelligence trends 2024",
    "AI research 2024", 
    "machine learning advancements 2024",
    "Generative AI trends 2024",
    "AI ethics 2024 developments",
    # ... 5 more optimized terms
]

# Results per term: up to 20 (increased from 10)
# Total possible results: 200 (10 terms × 20 results)
# Final filtered results: 15-25 high-quality URLs
```

## API Reference

### Main Methods

#### `process_query(user_query: str, **kwargs) -> SearchResponse`

Main method that processes a user query through the complete workflow.

**Parameters:**
- `user_query` (str): The user's query
- `max_results` (int): Maximum results per search term (default: **25**, increased from 8)
- `relevance_threshold` (float): Relevance threshold (default: 0.5, improved from 0.3)
- `query_type` (str): Type of query (default: "technical")
- `include_news` (bool): Include news results (default: **True**, improved)
- `include_academic` (bool): Include academic results (default: **True**, improved)

**Returns:**
- Dictionary containing:
  - `user_query`: Original query
  - `search_terms`: Generated search terms (now 10 terms)
  - `search_results`: Web search results (15-25 URLs)
  - `extracted_contents`: Extracted content with relevance scores
  - `summary`: Final summary with citations
  - `statistics`: Processing statistics

## Output Formats

### Clean Markdown Summary

The system generates clean markdown summaries without additional text:

```markdown
## Key Developments in AI 2024

**Large Language Models** have seen significant breakthroughs [Source 1], with improved reasoning capabilities and multimodal processing [Source 2].

### Technical Advancements
- Enhanced reasoning and problem-solving abilities [Source 1]
- Improved efficiency in training and inference [Source 3]
- Better integration with existing systems [Source 2]

### Industry Impact
The technology is transforming various sectors including healthcare, finance, and education [Source 1, Source 3].
```

### Excel Export

Professional Excel files with:
- Color-coded headers and sections
- Source citations and reference tables
- Enhanced formatting and styling
- Citation highlighting and notes

## Troubleshooting

### Getting Only 1-2 Sources

This is a common issue that can be fixed with optimized settings:

```python
# Use optimized configuration for more sources
config = ComponentConfig(
    max_search_results=25,      # Increased from default 10
    relevance_threshold=0.3,    # Lowered from default 0.7
    max_content_length=2000,    # Reduced for faster processing
    search_delay=0.5,           # Reduced delay
    page_load_timeout=10        # Reduced timeout
)

component = create_genai_component(
    llm_provider="google",
    config=config
)

# Process with more results
results = component.process_query(
    user_query="Your search query",
    max_results=8,              # Increased from default 3
    relevance_threshold=0.3     # Lowered significantly
)
```

### Common Issues

1. **ChromeDriver not found**: Install Chrome browser and ensure it's in PATH
2. **API key errors**: Verify your API keys are correct and have proper permissions
3. **Selenium errors**: Ensure Chrome browser is installed and up to date
4. **Network timeouts**: Check your internet connection and API service status

## Error Handling

The component includes comprehensive error handling:

- **Missing API Keys**: Clear error messages for missing credentials
- **Network Issues**: Graceful handling of web search failures
- **Content Extraction**: Fallback mechanisms for failed extractions
- **LLM Errors**: Robust error handling for LLM API calls

## Performance Considerations

- **Rate Limiting**: Built-in delays to respect API rate limits
- **Content Length**: Configurable content length limits
- **Browser Management**: Automatic WebDriver cleanup
- **Memory Management**: Efficient processing of large content

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For issues and questions:
1. Check the troubleshooting section
2. Review the examples
3. Open an issue on GitHub 