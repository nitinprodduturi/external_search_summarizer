#!/usr/bin/env python3
"""
GenAI Search Component - Main Entry Point

A comprehensive AI-powered search system that combines Large Language Models (LLMs) 
with web search capabilities to provide intelligent content discovery, extraction, 
and summarization with source citations.
"""

import os
import sys
from pathlib import Path
from dotenv import load_dotenv
from genai_search import create_genai_component
from genai_search.core.utils.models import ComponentConfig
from genai_search.exporters import ExcelExporter

def load_environment():
    """Load environment variables from .env file."""
    load_dotenv()
    
    # Check required API keys
    google_key = os.getenv("GOOGLE_API_KEY")
    serpapi_key = os.getenv("SERPAPI_API_KEY")
    
    if not google_key:
        print("ERROR: GOOGLE_API_KEY not found in environment")
        print("Please set your Google Generative AI API key in .env file")
        return False
    
    if not serpapi_key:
        print("ERROR: SERPAPI_API_KEY not found in environment")
        print("Please set your SerpAPI key in .env file")
        return False
    
    return True

def create_optimized_config():
    """Create optimized configuration for better results."""
    return ComponentConfig(
        max_search_results=50,      # Increased for more sources
        max_content_length=2000,    # Optimized for speed
        relevance_threshold=0.5,    # Increased for better quality
        headless_browser=True,
        search_delay=0.5,           # Reduced delay
        page_load_timeout=10,       # Reduced timeout
        llm_temperature=0.3,
        llm_max_tokens=2048
    )

def process_query(component, query, max_results=25, relevance_threshold=0.5):
    """Process a search query and return results."""
    print(f"Processing query: '{query}'")
    print("-" * 50)
    
    try:
        results = component.process_query(
            user_query=query,
            query_type="technical",
            max_results=max_results,
            relevance_threshold=relevance_threshold,
            include_news=True,
            include_academic=True
        )
        
        return results
    except Exception as e:
        print(f"Error processing query: {e}")
        return None

def display_results(results):
    """Display processing results and statistics."""
    if not results:
        return
    
    stats = results.statistics
    
    print("\nProcessing Statistics:")
    print(f"  Search Results: {stats.total_search_results}")
    print(f"  Extracted Contents: {stats.total_extracted_contents}")
    print(f"  Relevant Contents: {stats.relevant_contents}")
    print(f"  Average Relevance: {stats.average_relevance_score:.2f}")
    print(f"  Processing Time: {stats.processing_time:.2f}s")
    
    print("\nSearch Terms Generated:")
    terms_list = results.search_terms.search_terms if getattr(results, 'search_terms', None) and getattr(results.search_terms, 'search_terms', None) else []
    if not terms_list:
        print("  (none)")
    else:
        for i, term in enumerate(terms_list, 1):
            print(f"  {i}. {term}")
    
    print("\nSummary with Source Citations:")
    print("=" * 50)
    print(results.summary)
    print("=" * 50)

def export_to_excel(results, query, output_dir="runs"):
    """Export results to Excel with enhanced styling."""
    try:
        print("\nExporting to Excel...")
        exporter = ExcelExporter(output_dir=output_dir)
        
        stats = results.statistics
        terms_list = results.search_terms.search_terms if getattr(results, 'search_terms', None) and getattr(results.search_terms, 'search_terms', None) else []
        
        xlsx_path = exporter.export(
            user_query=query,
            config={
                "llm_provider": "google",
                "search_engine": "google",
                "max_search_results": 25,
                "relevance_threshold": 0.3,
                "headless_browser": True
            },
            search_terms={
                "search_terms": terms_list,
                "confidence_scores": getattr(results.search_terms, 'confidence_scores', []) if getattr(results, 'search_terms', None) else []
            } if terms_list else None,
            search_results=results.search_results,
            extracted_contents=results.extracted_contents,
            summary=results.summary,
            statistics={
                "total_search_results": stats.total_search_results,
                "total_extracted_contents": stats.total_extracted_contents,
                "relevant_contents": stats.relevant_contents,
                "average_relevance_score": stats.average_relevance_score,
                "processing_time": stats.processing_time
            }
        )
        
        print(f"Excel file saved: {xlsx_path}")
        return xlsx_path
    except Exception as e:
        print(f"Error exporting to Excel: {e}")
        return None

def save_markdown(results, query, output_dir="runs"):
    """Save summary to markdown file."""
    try:
        os.makedirs(output_dir, exist_ok=True)
        markdown_file = os.path.join(output_dir, f"summary_{query.replace(' ', '_')[:30]}.md")
        
        with open(markdown_file, "w", encoding="utf-8") as f:
            f.write(results.summary)
        
        print(f"Markdown file saved: {markdown_file}")
        return markdown_file
    except Exception as e:
        print(f"Error saving markdown: {e}")
        return None

def main():
    """Main function to execute the GenAI Search Component."""
    print("GenAI Search Component")
    print("=" * 50)
    
    # Load environment
    if not load_environment():
        sys.exit(1)
    
    # Create optimized configuration
    config = create_optimized_config()
    
    # Initialize component
    print("\nInitializing GenAI Search Component...")
    component = create_genai_component(
        llm_provider="google",
        search_engine="google",  # Use Google search with SerpAPI
        config=config
    )
    
    try:
        # Get query from user or use default
        if len(sys.argv) > 1:
            query = " ".join(sys.argv[1:])
        else:
            query = input("\nEnter your search query (or press Enter for default): ").strip()
            if not query:
                query = "latest developments in artificial intelligence and machine learning 2024"
        
        # Process query
        results = process_query(component, query)
        
        if results:
            # Display results
            display_results(results)
            
            # Export options
            print("\nExport Options:")
            print("1. Excel file (recommended)")
            print("2. Markdown file")
            print("3. Both")
            print("4. None")
            
            choice = input("\nChoose export option (1-4): ").strip()
            
            if choice in ['1', '3']:
                export_to_excel(results, query)
            
            if choice in ['2', '3']:
                save_markdown(results, query)
            
            print("\nProcessing completed successfully!")
        else:
            print("Failed to process query. Please check your API keys and try again.")
    
    except KeyboardInterrupt:
        print("\nOperation cancelled by user.")
    except Exception as e:
        print(f"\nUnexpected error: {e}")
    finally:
        # Clean up
        try:
            component.close()
            print("Resources cleaned up.")
        except:
            pass

if __name__ == "__main__":
    main() 