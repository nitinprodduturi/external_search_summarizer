"""
Excel exporter for GenAI Search runs

Creates a formatted Excel file with separate worksheets for:
- Input & configuration
- Search terms
- Search results (SERP)
- Extracted content
- Relevance scores
- Final summary & statistics
"""

import os
from typing import List, Dict, Any, Optional
from datetime import datetime
import re # Added for enhanced summary parsing

try:
    import pandas as pd
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side, NamedStyle
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.worksheet import Worksheet
    EXCEL_AVAILABLE = True
except Exception:
    EXCEL_AVAILABLE = False

from genai_search.core.utils.models import ExtractedContent

class ExcelExporter:
    """Exports a full run to a formatted Excel workbook with enhanced styling."""

    def __init__(self, output_dir: str = "runs"):
        self.output_dir = output_dir
        os.makedirs(self.output_dir, exist_ok=True)
        
        # Define color scheme
        self.colors = {
            'header_bg': 'FF2E86AB',      # Blue header
            'header_text': 'FFFFFFFF',    # White header text
            'subheader_bg': 'FFA23B72',   # Purple subheader
            'subheader_text': 'FFFFFFFF', # White subheader text
            'alternate_row': 'FFF8F9FA',  # Light gray alternate rows
            'border': 'FFDEE2E6',         # Light gray border
            'highlight': 'FFE3F2FD',      # Light blue highlight
            'success': 'FFD4EDDA',        # Light green success
            'warning': 'FFFEF3CD',        # Light yellow warning
        }

    def export(
        self,
        user_query: str,
        config: Dict[str, Any],
        search_terms: Optional[Dict[str, Any]],
        search_results: List[Dict[str, Any]],
        extracted_contents: List[Dict[str, Any]],
        summary: str,
        statistics: Dict[str, Any],
        run_id: Optional[str] = None
    ) -> str:
        if not EXCEL_AVAILABLE:
            raise RuntimeError("pandas and openpyxl are required for Excel export. Install: pip install pandas openpyxl")

        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        run_id = run_id or f"run_{ts}"
        file_path = os.path.join(self.output_dir, f"{run_id}.xlsx")

        # Build DataFrames
        input_df = pd.DataFrame([
            {"key": "user_query", "value": user_query},
            *({"key": k, "value": v} for k, v in (config or {}).items())
        ])

        terms_df = pd.DataFrame((search_terms or {}).get("search_terms", []), columns=["search_term"]) if search_terms else pd.DataFrame(columns=["search_term"])
        if search_terms and search_terms.get("confidence_scores"):
            # Align sizes
            scores = search_terms.get("confidence_scores", [])
            while len(scores) < len(terms_df):
                scores.append(None)
            terms_df["confidence_score"] = scores[: len(terms_df)]

        serp_df = pd.DataFrame(search_results or [])
        extracted_df = pd.DataFrame(extracted_contents or [])
        
        # Create enhanced summary DataFrame with citations
        summary_df = self._create_enhanced_summary_df(summary, extracted_contents)
        
        stats_df = pd.DataFrame(list((statistics or {}).items()), columns=["metric", "value"]) if statistics else pd.DataFrame(columns=["metric", "value"]) 

        with pd.ExcelWriter(file_path, engine="openpyxl") as writer:
            # Write data to sheets
            input_df.to_excel(writer, sheet_name="Input & Config", index=False)
            terms_df.to_excel(writer, sheet_name="Search Terms", index=False)
            serp_df.to_excel(writer, sheet_name="Search Results", index=False)
            extracted_df.to_excel(writer, sheet_name="Extracted Content", index=False)
            summary_df.to_excel(writer, sheet_name="Summary", index=False)
            stats_df.to_excel(writer, sheet_name="Statistics", index=False)

            # Apply enhanced formatting
            wb = writer.book
            self._apply_enhanced_formatting(wb)

        return file_path

    def _create_enhanced_summary_df(self, summary: str, extracted_contents: List[Dict[str, Any]]) -> pd.DataFrame:
        """Create an enhanced summary DataFrame with proper citation formatting."""
        
        # Parse the summary to extract citations and create structured data
        summary_parts = self._parse_summary_with_citations(summary)
        
        # Create DataFrame with summary sections and citations
        summary_data = []
        
        # Add main summary (clean markdown)
        summary_data.append({
            "section": "Summary",
            "content": summary_parts.get("main_summary", summary),
            "citations": summary_parts.get("citations", []),
            "source_details": ""
        })
        
        # Add source references if available
        if extracted_contents:
            source_references = self._create_source_references(extracted_contents)
            summary_data.append({
                "section": "Source References",
                "content": source_references,
                "citations": [],
                "source_details": ""
            })
        
        return pd.DataFrame(summary_data)

    def _parse_summary_with_citations(self, summary: str) -> Dict[str, Any]:
        """Parse summary to extract citations and structure the content."""
        
        # Look for citation patterns
        citation_patterns = [
            r'\[Source (\d+)\]',  # [Source 1], [Source 2], etc.
            r'Source (\d+):',     # Source 1:, Source 2:, etc.
            r'\(Source (\d+)\)',  # (Source 1), (Source 2), etc.
        ]
        
        citations = []
        main_summary = summary
        
        # Extract citations
        for pattern in citation_patterns:
            matches = re.findall(pattern, summary, re.IGNORECASE)
            citations.extend([f"Source {match}" for match in matches])
        
        # Remove duplicate citations
        citations = list(set(citations))
        
        return {
            "main_summary": main_summary,
            "citations": citations
        }

    def _create_source_references(self, extracted_contents: List[Dict[str, Any]]) -> str:
        """Create a formatted source reference table."""
        
        references = []
        for i, content in enumerate(extracted_contents, 1):
            ref = f"**[Source {i}]** {content.get('title', 'Untitled')}\n"
            ref += f"*URL:* {content.get('url', 'N/A')}\n"
            ref += f"*Relevance:* {content.get('relevance_score', 0):.2f}\n"
            ref += f"*Type:* {content.get('content_type', 'Unknown')}\n"
            ref += f"*Word Count:* {content.get('word_count', 0)}\n\n"
            references.append(ref)
        
        return "".join(references)

    def _apply_enhanced_formatting(self, workbook):
        """Apply comprehensive formatting to all worksheets."""
        
        # Create named styles
        self._create_named_styles(workbook)
        
        for sheet_name in workbook.sheetnames:
            ws = workbook[sheet_name]
            self._format_worksheet(ws, sheet_name)

    def _create_named_styles(self, workbook):
        """Create reusable named styles for consistent formatting."""
        
        # Header style
        header_style = NamedStyle(name="Header")
        header_style.font = Font(bold=True, color=self.colors['header_text'], size=12)
        header_style.fill = PatternFill(start_color=self.colors['header_bg'], end_color=self.colors['header_bg'], fill_type="solid")
        header_style.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        header_style.border = self._create_border()
        workbook.add_named_style(header_style)
        
        # Subheader style
        subheader_style = NamedStyle(name="Subheader")
        subheader_style.font = Font(bold=True, color=self.colors['subheader_text'], size=11)
        subheader_style.fill = PatternFill(start_color=self.colors['subheader_bg'], end_color=self.colors['subheader_bg'], fill_type="solid")
        subheader_style.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        subheader_style.border = self._create_border()
        workbook.add_named_style(subheader_style)
        
        # Data style
        data_style = NamedStyle(name="Data")
        data_style.font = Font(size=10)
        data_style.alignment = Alignment(vertical="top", wrap_text=True)
        data_style.border = self._create_border()
        workbook.add_named_style(data_style)
        
        # Highlight style
        highlight_style = NamedStyle(name="Highlight")
        highlight_style.font = Font(size=10, bold=True)
        highlight_style.fill = PatternFill(start_color=self.colors['highlight'], end_color=self.colors['highlight'], fill_type="solid")
        highlight_style.alignment = Alignment(vertical="top", wrap_text=True)
        highlight_style.border = self._create_border()
        workbook.add_named_style(highlight_style)

    def _create_border(self) -> Border:
        """Create a consistent border style."""
        thin = Side(border_style="thin", color=self.colors['border'])
        return Border(left=thin, right=thin, top=thin, bottom=thin)

    def _format_worksheet(self, ws: Worksheet, sheet_name: str):
        """Apply formatting to a specific worksheet."""
        
        # Apply header styling
        for cell in ws[1]:
            cell.style = "Header"
        
        # Apply data styling and alternate row colors
        for row_idx in range(2, ws.max_row + 1):
            for col_idx in range(1, ws.max_column + 1):
                cell = ws.cell(row=row_idx, column=col_idx)
                cell.style = "Data"
                
                # Alternate row colors
                if row_idx % 2 == 0:
                    cell.fill = PatternFill(start_color=self.colors['alternate_row'], end_color=self.colors['alternate_row'], fill_type="solid")
        
        # Special formatting for specific sheets
        if sheet_name == "Input & Config":
            self._format_input_config_sheet(ws)
        elif sheet_name == "Search Terms":
            self._format_search_terms_sheet(ws)
        elif sheet_name == "Search Results":
            self._format_search_results_sheet(ws)
        elif sheet_name == "Extracted Content":
            self._format_extracted_content_sheet(ws)
        elif sheet_name == "Summary":
            self._format_summary_sheet(ws)
        elif sheet_name == "Statistics":
            self._format_statistics_sheet(ws)
        
        # Auto-adjust column widths
        self._auto_adjust_columns(ws)
        
        # Freeze header row
        ws.freeze_panes = "A2"

    def _format_input_config_sheet(self, ws: Worksheet):
        """Apply special formatting to Input & Config sheet."""
        # Highlight user query row
        if ws.max_row > 1:
            for col in range(1, ws.max_column + 1):
                cell = ws.cell(row=2, column=col)
                cell.style = "Highlight"
        
        # Add title
        ws.insert_rows(1, 1)
        title_cell = ws.cell(row=1, column=1, value="GenAI Search Configuration")
        title_cell.font = Font(bold=True, size=14, color=self.colors['header_text'])
        title_cell.fill = PatternFill(start_color=self.colors['header_bg'], end_color=self.colors['header_bg'], fill_type="solid")
        ws.merge_cells('A1:B1')
        title_cell.alignment = Alignment(horizontal="center", vertical="center")

    def _format_search_terms_sheet(self, ws: Worksheet):
        """Apply special formatting to Search Terms sheet."""
        # Add title
        ws.insert_rows(1, 1)
        title_cell = ws.cell(row=1, column=1, value="Generated Search Terms")
        title_cell.font = Font(bold=True, size=14, color=self.colors['header_text'])
        title_cell.fill = PatternFill(start_color=self.colors['header_bg'], end_color=self.colors['header_bg'], fill_type="solid")
        ws.merge_cells(f'A1:{get_column_letter(ws.max_column)}1')
        title_cell.alignment = Alignment(horizontal="center", vertical="center")
        
        # Highlight confidence scores
        if ws.max_column > 1:
            for row in range(3, ws.max_row + 1):
                cell = ws.cell(row=row, column=2)
                if cell.value is not None:
                    try:
                        score = float(cell.value)
                        if score >= 0.8:
                            cell.fill = PatternFill(start_color=self.colors['success'], end_color=self.colors['success'], fill_type="solid")
                        elif score >= 0.6:
                            cell.fill = PatternFill(start_color=self.colors['warning'], end_color=self.colors['warning'], fill_type="solid")
                    except (ValueError, TypeError):
                        pass

    def _format_search_results_sheet(self, ws: Worksheet):
        """Apply special formatting to Search Results sheet."""
        # Add title
        ws.insert_rows(1, 1)
        title_cell = ws.cell(row=1, column=1, value="Web Search Results")
        title_cell.font = Font(bold=True, size=14, color=self.colors['header_text'])
        title_cell.fill = PatternFill(start_color=self.colors['header_bg'], end_color=self.colors['header_bg'], fill_type="solid")
        ws.merge_cells(f'A1:{get_column_letter(ws.max_column)}1')
        title_cell.alignment = Alignment(horizontal="center", vertical="center")
        
        # Highlight relevance scores
        relevance_col = None
        for col in range(1, ws.max_column + 1):
            if ws.cell(row=2, column=col).value and 'relevance' in str(ws.cell(row=2, column=col).value).lower():
                relevance_col = col
                break
        
        if relevance_col:
            for row in range(3, ws.max_row + 1):
                cell = ws.cell(row=row, column=relevance_col)
                if cell.value is not None:
                    try:
                        score = float(cell.value)
                        if score >= 0.8:
                            cell.fill = PatternFill(start_color=self.colors['success'], end_color=self.colors['success'], fill_type="solid")
                        elif score >= 0.6:
                            cell.fill = PatternFill(start_color=self.colors['warning'], end_color=self.colors['warning'], fill_type="solid")
                    except (ValueError, TypeError):
                        pass

    def _format_extracted_content_sheet(self, ws: Worksheet):
        """Apply special formatting to Extracted Content sheet."""
        # Add title
        ws.insert_rows(1, 1)
        title_cell = ws.cell(row=1, column=1, value="Extracted Web Content")
        title_cell.font = Font(bold=True, size=14, color=self.colors['header_text'])
        title_cell.fill = PatternFill(start_color=self.colors['header_bg'], end_color=self.colors['header_bg'], fill_type="solid")
        ws.merge_cells(f'A1:{get_column_letter(ws.max_column)}1')
        title_cell.alignment = Alignment(horizontal="center", vertical="center")
        
        # Highlight word count and relevance score columns
        for col in range(1, ws.max_column + 1):
            header_value = ws.cell(row=2, column=col).value
            if header_value and ('word_count' in str(header_value).lower() or 'relevance' in str(header_value).lower()):
                for row in range(3, ws.max_row + 1):
                    cell = ws.cell(row=row, column=col)
                    if cell.value is not None:
                        try:
                            value = float(cell.value)
                            if 'relevance' in str(header_value).lower():
                                if value >= 0.8:
                                    cell.fill = PatternFill(start_color=self.colors['success'], end_color=self.colors['success'], fill_type="solid")
                                elif value >= 0.6:
                                    cell.fill = PatternFill(start_color=self.colors['warning'], end_color=self.colors['warning'], fill_type="solid")
                        except (ValueError, TypeError):
                            pass

    def _format_summary_sheet(self, ws: Worksheet):
        """Apply special formatting to Summary sheet with citations."""
        # Add title
        ws.insert_rows(1, 1)
        title_cell = ws.cell(row=1, column=1, value="AI-Generated Summary with Source Citations")
        title_cell.font = Font(bold=True, size=14, color=self.colors['header_text'])
        title_cell.fill = PatternFill(start_color=self.colors['header_bg'], end_color=self.colors['header_bg'], fill_type="solid")
        ws.merge_cells(f'A1:{get_column_letter(ws.max_column)}1')
        title_cell.alignment = Alignment(horizontal="center", vertical="center")
        
        # Format summary sections
        if ws.max_row > 2:
            for row in range(3, ws.max_row + 1):
                section_cell = ws.cell(row=row, column=1)
                content_cell = ws.cell(row=row, column=2)
                citations_cell = ws.cell(row=row, column=3)
                
                # Format section headers
                if section_cell.value and "Summary" in str(section_cell.value):
                    section_cell.font = Font(bold=True, size=12, color=self.colors['subheader_text'])
                    section_cell.fill = PatternFill(start_color=self.colors['subheader_bg'], end_color=self.colors['subheader_bg'], fill_type="solid")
                
                # Format content with markdown awareness
                if content_cell.value:
                    content_cell.font = Font(size=11)
                    content_cell.alignment = Alignment(vertical="top", wrap_text=True, horizontal="left")
                    content_cell.fill = PatternFill(start_color=self.colors['highlight'], end_color=self.colors['highlight'], fill_type="solid")
                    
                    # Preserve markdown formatting in Excel
                    self._preserve_markdown_formatting(content_cell)
                
                # Format citations
                if citations_cell.value:
                    citations_cell.font = Font(size=10, italic=True)
                    citations_cell.alignment = Alignment(vertical="top", wrap_text=True, horizontal="left")
                    citations_cell.fill = PatternFill(start_color=self.colors['warning'], end_color=self.colors['warning'], fill_type="solid")
        
        # Highlight citation patterns in content
        self._highlight_citations_in_summary(ws)

    def _preserve_markdown_formatting(self, cell):
        """Preserve markdown formatting in Excel cells."""
        if not cell.value or not isinstance(cell.value, str):
            return
        
        content = cell.value
        
        # Convert markdown headers to bold
        content = re.sub(r'^##\s+(.+)$', r'**\1**', content, flags=re.MULTILINE)
        content = re.sub(r'^###\s+(.+)$', r'**\1**', content, flags=re.MULTILINE)
        
        # Convert markdown bold to Excel bold (if possible)
        # Note: Excel doesn't support rich text in single cells, so we preserve the markdown syntax
        # Users can copy to a markdown editor for proper rendering
        
        cell.value = content

    def _highlight_citations_in_summary(self, ws: Worksheet):
        """Highlight citation patterns in the summary content."""
        if ws.max_row < 3:
            return
            
        # Look for citation patterns in content column
        for row in range(3, ws.max_row + 1):
            content_cell = ws.cell(row=row, column=2)
            if content_cell.value and isinstance(content_cell.value, str):
                content = content_cell.value
                
                # Highlight citation patterns
                citation_patterns = [
                    r'\[Source \d+\]',  # [Source 1], [Source 2], etc.
                    r'Source \d+:',     # Source 1:, Source 2:, etc.
                    r'\(Source \d+\)',  # (Source 1), (Source 2), etc.
                ]
                
                for pattern in citation_patterns:
                    if re.search(pattern, content, re.IGNORECASE):
                        # Add a note about citations
                        note_cell = ws.cell(row=row, column=4)
                        note_cell.value = "Contains source citations"
                        note_cell.font = Font(size=9, italic=True, color=self.colors['subheader_bg'])
                        note_cell.fill = PatternFill(start_color=self.colors['success'], end_color=self.colors['success'], fill_type="solid")
                        break

    def _format_statistics_sheet(self, ws: Worksheet):
        """Apply special formatting to Statistics sheet."""
        # Add title
        ws.insert_rows(1, 1)
        title_cell = ws.cell(row=1, column=1, value="Processing Statistics")
        title_cell.font = Font(bold=True, size=14, color=self.colors['header_text'])
        title_cell.fill = PatternFill(start_color=self.colors['header_bg'], end_color=self.colors['header_bg'], fill_type="solid")
        ws.merge_cells(f'A1:{get_column_letter(ws.max_column)}1')
        title_cell.alignment = Alignment(horizontal="center", vertical="center")
        
        # Highlight key metrics
        key_metrics = ['total_search_results', 'total_extracted_contents', 'relevant_contents', 'average_relevance_score']
        for row in range(3, ws.max_row + 1):
            metric_cell = ws.cell(row=row, column=1)
            if metric_cell.value and any(key_metric in str(metric_cell.value).lower() for key_metric in key_metrics):
                metric_cell.fill = PatternFill(start_color=self.colors['highlight'], end_color=self.colors['highlight'], fill_type="solid")

    def _auto_adjust_columns(self, ws: Worksheet):
        """Automatically adjust column widths for optimal readability."""
        for col in ws.columns:
            max_len = 0
            col_letter = get_column_letter(col[0].column)
            
            for cell in col:
                try:
                    if cell.value:
                        val = str(cell.value)
                        # Count characters considering line breaks
                        lines = val.split('\n')
                        max_line_len = max(len(line) for line in lines)
                        max_len = max(max_len, max_line_len)
                except Exception:
                    pass
            
            # Set column width with reasonable limits
            optimal_width = min(max(12, max_len + 2), 100)
            ws.column_dimensions[col_letter].width = optimal_width 