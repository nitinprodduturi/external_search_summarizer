"""
GenAI Search Package

A comprehensive AI-powered search component that generates search terms,
performs web searches, extracts content, scores relevance, and creates summaries.
"""

from .core import create_genai_component, GenAISearchOrchestrator  # noqa: F401 