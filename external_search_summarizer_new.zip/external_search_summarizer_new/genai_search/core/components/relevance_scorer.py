"""
Relevance Scorer Component (organized package)
"""

import re
from typing import List, Optional

from genai_search.core.utils.logging_config import LoggedClass, log_execution_time
from genai_search.core.utils.models import ExtractedContent, ComponentConfig
from genai_search.core.utils.prompts import (
    RELEVANCE_SYSTEM_PROMPT,
    RELEVANCE_HUMAN_PROMPT,
    PROMPT_TEMPLATES,
)
from genai_search.core.llm_manager import LLMManager

class RelevanceScorer(LoggedClass):
    """Scores the relevance of extracted content using LLM"""
    
    def __init__(self, 
                 llm_manager: LLMManager,
                 config: Optional[ComponentConfig] = None):
        super().__init__("RelevanceScorer")
        self.llm_manager = llm_manager
        self.config = config or ComponentConfig()
        self.logger.info("Relevance Scorer initialized")
    
    @log_execution_time
    def calculate_relevance_scores(self, 
                                 user_query: str, 
                                 extracted_contents: List[ExtractedContent],
                                 query_type: str = "general") -> List[ExtractedContent]:
        self.logger.info(f"Calculating relevance scores for {len(extracted_contents)} content pieces")
        scored_contents = []
        
        for i, content in enumerate(extracted_contents):
            self.logger.debug(f"Scoring content {i+1}/{len(extracted_contents)}: {content.title}")
            try:
                score = self._score_single_content(user_query, content, query_type)
                content.relevance_score = score
                scored_contents.append(content)
                self.logger.debug(f"Relevance score for {content.url}: {score}")
            except Exception as e:
                self.logger.error(f"Failed to score content {content.url}: {e}")
                content.relevance_score = 0.5
                scored_contents.append(content)
        
        self.logger.info(f"Completed relevance scoring for {len(scored_contents)} content pieces")
        return scored_contents
    
    def _score_single_content(self, user_query: str, content: ExtractedContent, query_type: str) -> float:
        try:
            # Pre-validate content quality before LLM scoring
            quality_score = self._validate_content_quality(content)
            if quality_score < 0.3:
                self.logger.warning(f"Content quality too low for {content.url}: {quality_score}")
                return quality_score
            
            system_prompt, human_prompt = self._get_prompts(query_type)
            content_preview = content.content[:1000]
            
            result = self.llm_manager.generate_text(
                system_prompt=system_prompt,
                human_prompt=human_prompt,
                inputs={
                    "query": user_query,
                    "title": content.title,
                    "content": content_preview
                }
            )
            
            score = self._parse_relevance_score(result)
            
            # Apply content quality penalty if content is too short
            if content.word_count < 100:
                score *= 0.5
                self.logger.debug(f"Applied word count penalty for {content.url}: {score}")
            
            return max(0.0, min(1.0, score))
        except Exception as e:
            self.logger.error(f"Error scoring content: {e}")
            return self._fallback_scoring(user_query, content)
    
    def _validate_content_quality(self, content: ExtractedContent) -> float:
        """Pre-validate content quality before LLM scoring"""
        score = 1.0
        
        # Penalize very short content
        if content.word_count < 50:
            score *= 0.2
        elif content.word_count < 100:
            score *= 0.5
        elif content.word_count < 200:
            score *= 0.8
        
        # Penalize content that's mostly navigation/ads
        content_lower = content.content.lower()
        navigation_words = ['sign up', 'log in', 'menu', 'navigation', 'read more', 'click here', 'subscribe']
        if any(word in content_lower for word in navigation_words):
            score *= 0.6
        
        # Penalize promotional content
        promotional_words = ['official', 'unlock', 'automation', 'everyone', 'read more']
        if any(word in content_lower for word in promotional_words):
            score *= 0.7
        
        return max(0.0, min(1.0, score))
    
    def _get_prompts(self, query_type: str) -> tuple[str, str]:
        if query_type in PROMPT_TEMPLATES:
            template = PROMPT_TEMPLATES[query_type]["relevance"]
            return RELEVANCE_SYSTEM_PROMPT, template
        return RELEVANCE_SYSTEM_PROMPT, RELEVANCE_HUMAN_PROMPT
    
    def _parse_relevance_score(self, llm_result: str) -> float:
        try:
            score_patterns = [
                r'(\d+\.?\d*)',
                r'score[:\s]*(\d+\.?\d*)',
                r'(\d+\.?\d*)/10',
                r'(\d+\.?\d*)%',
            ]
            
            for pattern in score_patterns:
                match = re.search(pattern, llm_result, re.IGNORECASE)
                if match:
                    score = float(match.group(1))
                    if '%' in llm_result:
                        score = score / 100
                    if '/10' in llm_result:
                        score = score / 10
                    return max(0.0, min(1.0, score))
            
            return 0.5
        except Exception as e:
            self.logger.warning(f"Failed to parse relevance score: {e}")
            return 0.5
    
    def _fallback_scoring(self, user_query: str, content: ExtractedContent) -> float:
        try:
            query_words = set(user_query.lower().split())
            content_words = set(content.content.lower().split())
            title_words = set(content.title.lower().split())
            
            content_overlap = len(query_words.intersection(content_words))
            title_overlap = len(query_words.intersection(title_words))
            
            total_overlap = content_overlap + (title_overlap * 2)
            max_possible = len(query_words) * 3
            
            score = (total_overlap / max_possible) if max_possible > 0 else 0.5
            
            if content.word_count > 200:
                score *= 1.1
            
            return min(score, 1.0)
        except Exception as e:
            self.logger.error(f"Fallback scoring failed: {e}")
            return 0.5 