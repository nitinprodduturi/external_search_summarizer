"""
Web Search Engine Component (organized package)
"""

import os
import time
import requests
from typing import List, Dict, Any, Optional
from datetime import datetime
from urllib.parse import urlparse

from genai_search.core.utils.logging_config import LoggedClass, log_execution_time
from genai_search.core.utils.models import SearchResult, SearchEngine, ComponentConfig

try:
    from serpapi import GoogleSearch
    SERPAPI_AVAILABLE = True
except ImportError:
    SERPAPI_AVAILABLE = False

class WebSearchEngine(LoggedClass):
    """Handles web search operations using various search engines"""
    
    def __init__(self, 
                 search_engine: SearchEngine = SearchEngine.GOOGLE,
                 config: Optional[ComponentConfig] = None):
        super().__init__("WebSearchEngine")
        self.search_engine = search_engine
        self.config = config or ComponentConfig()
        self._validate_api_keys()
        self.logger.info(f"Web Search Engine initialized with {search_engine}")
    
    def _validate_api_keys(self) -> None:
        if self.search_engine == SearchEngine.GOOGLE:
            api_key = os.getenv("SERPAPI_API_KEY")
            if not api_key:
                raise ValueError("SerpAPI key is required for Google search. Set SERPAPI_API_KEY environment variable.")
        elif self.search_engine == SearchEngine.DUCKDUCKGO:
            # DuckDuckGo doesn't require API keys
            pass
        elif self.search_engine == SearchEngine.BING:
            api_key = os.getenv("BING_API_KEY")
            if not api_key:
                raise ValueError("Bing API key is required for Bing search. Set BING_API_KEY environment variable.")
    
    @log_execution_time
    def search(self, 
              search_terms: List[str], 
              max_results_per_term: int = 10,
              include_news: bool = False,
              include_academic: bool = False) -> List[SearchResult]:
        self.logger.info(f"Performing web search for {len(search_terms)} terms")
        all_results = []
        
        for i, search_term in enumerate(search_terms):
            self.logger.debug(f"Searching for term {i+1}/{len(search_terms)}: '{search_term}'")
            try:
                results = self._search_single_term(search_term, max_results_per_term, include_news, include_academic)
                all_results.extend(results)
                if i < len(search_terms) - 1:
                    time.sleep(self.config.search_delay)
            except Exception as e:
                self.logger.error(f"Failed to search for term '{search_term}': {e}")
                continue
        
        unique_results = self._remove_duplicates(all_results)
        self.logger.info(f"Found {len(unique_results)} unique search results")
        return unique_results[:self.config.max_search_results]
    
    def _search_single_term(self, search_term: str, max_results: int, include_news: bool, include_academic: bool) -> List[SearchResult]:
        if self.search_engine == SearchEngine.GOOGLE:
            return self._google_search(search_term, max_results, include_news, include_academic)
        elif self.search_engine == SearchEngine.DUCKDUCKGO:
            return self._duckduckgo_search(search_term, max_results, include_news, include_academic)
        elif self.search_engine == SearchEngine.BING:
            return self._bing_search(search_term, max_results, include_news, include_academic)
        else:
            raise ValueError(f"Search engine {self.search_engine} not implemented")
    
    def _duckduckgo_search(self, search_term: str, max_results: int, include_news: bool, include_academic: bool) -> List[SearchResult]:
        """Search using DuckDuckGo Instant Answer API"""
        try:
            # DuckDuckGo Instant Answer API
            url = "https://api.duckduckgo.com/"
            params = {
                "q": search_term,
                "format": "json",
                "no_html": "1",
                "skip_disambig": "1"
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            data = response.json()
            
            search_results = []
            
            # Add instant answer if available
            if data.get("Abstract"):
                search_result = SearchResult(
                    title=data.get("Heading", search_term),
                    url=data.get("AbstractURL", ""),
                    snippet=data.get("Abstract", ""),
                    source="duckduckgo",
                    timestamp=datetime.now(),
                    metadata={
                        "source_type": "instant_answer",
                        "image": data.get("Image", ""),
                        "related_topics": len(data.get("RelatedTopics", []))
                    }
                )
                search_results.append(search_result)
            
            # Add related topics
            for topic in data.get("RelatedTopics", [])[:max_results-1]:
                if isinstance(topic, dict) and "Text" in topic:
                    search_result = SearchResult(
                        title=topic.get("Text", "").split(" - ")[0] if " - " in topic.get("Text", "") else topic.get("Text", ""),
                        url=topic.get("FirstURL", ""),
                        snippet=topic.get("Text", ""),
                        source="duckduckgo",
                        timestamp=datetime.now(),
                        metadata={
                            "source_type": "related_topic",
                            "icon": topic.get("Icon", {})
                        }
                    )
                    search_results.append(search_result)
            
            # If we don't have enough results, try web search
            if len(search_results) < max_results:
                web_results = self._duckduckgo_web_search(search_term, max_results - len(search_results))
                search_results.extend(web_results)
            
            self.logger.debug(f"Found {len(search_results)} DuckDuckGo results for '{search_term}'")
            return search_results[:max_results]
            
        except Exception as e:
            self.logger.error(f"DuckDuckGo search failed for '{search_term}': {e}")
            return []
    
    def _duckduckgo_web_search(self, search_term: str, max_results: int) -> List[SearchResult]:
        """Fallback web search using DuckDuckGo HTML search"""
        try:
            # Use DuckDuckGo HTML search as fallback
            url = "https://html.duckduckgo.com/html/"
            params = {
                "q": search_term
            }
            
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
            }
            
            response = requests.get(url, params=params, headers=headers, timeout=10)
            response.raise_for_status()
            
            # Simple HTML parsing for results
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(response.text, 'html.parser')
            
            search_results = []
            result_links = soup.find_all('a', class_='result__a')
            
            for i, link in enumerate(result_links[:max_results]):
                title = link.get_text(strip=True)
                url = link.get('href', '')
                
                # Find snippet
                snippet_elem = link.find_next('a', class_='result__snippet')
                snippet = snippet_elem.get_text(strip=True) if snippet_elem else ""
                
                search_result = SearchResult(
                    title=title,
                    url=url,
                    snippet=snippet,
                    source="duckduckgo",
                    timestamp=datetime.now(),
                    metadata={
                        "source_type": "web_search",
                        "position": i + 1
                    }
                )
                search_results.append(search_result)
            
            return search_results
            
        except Exception as e:
            self.logger.error(f"DuckDuckGo web search failed for '{search_term}': {e}")
            return []
    
    def _bing_search(self, search_term: str, max_results: int, include_news: bool, include_academic: bool) -> List[SearchResult]:
        """Search using Bing Web Search API"""
        # Placeholder for Bing search implementation
        self.logger.warning("Bing search not yet implemented")
        return []
    
    def _google_search(self, search_term: str, max_results: int, include_news: bool, include_academic: bool) -> List[SearchResult]:
        if not SERPAPI_AVAILABLE:
            raise ImportError("SerpAPI is not available. Install with: pip install google-search-results")
        
        try:
            search_params = {
                "q": search_term,
                "api_key": os.getenv("SERPAPI_API_KEY"),
                "num": min(max_results, 20),
                "hl": "en",
                "gl": "us"
            }
            
            if include_news:
                search_params["tbm"] = "nws"
            
            search = GoogleSearch(search_params)
            results = search.get_dict()
            search_results = []
            
            if "organic_results" in results:
                for result in results["organic_results"]:
                    search_result = SearchResult(
                        title=result.get("title", ""),
                        url=result.get("link", ""),
                        snippet=result.get("snippet", ""),
                        source="google",
                        timestamp=datetime.now(),
                        metadata={
                            "position": result.get("position", 0),
                            "displayed_link": result.get("displayed_link", ""),
                            "source_type": "organic"
                        }
                    )
                    search_results.append(search_result)
            
            if include_news and "news_results" in results:
                for result in results["news_results"]:
                    search_result = SearchResult(
                        title=result.get("title", ""),
                        url=result.get("link", ""),
                        snippet=result.get("snippet", ""),
                        source="google_news",
                        timestamp=datetime.now(),
                        metadata={
                            "date": result.get("date", ""),
                            "source_type": "news"
                        }
                    )
                    search_results.append(search_result)
            
            self.logger.debug(f"Found {len(search_results)} results for '{search_term}'")
            return search_results
            
        except Exception as e:
            self.logger.error(f"Google search failed for '{search_term}': {e}")
            return []
    
    def _remove_duplicates(self, results: List[SearchResult]) -> List[SearchResult]:
        seen_urls = set()
        unique_results = []
        for result in results:
            normalized_url = self._normalize_url(result.url)
            if normalized_url not in seen_urls:
                unique_results.append(result)
                seen_urls.add(normalized_url)
        return unique_results
    
    def _normalize_url(self, url: str) -> str:
        try:
            parsed = urlparse(url)
            normalized = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
            return normalized.lower()
        except Exception:
            return url.lower() 