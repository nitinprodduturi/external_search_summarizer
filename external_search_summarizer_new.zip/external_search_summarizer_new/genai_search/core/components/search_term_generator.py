"""
Search Term Generator for the GenAI Search Component

This module handles the generation of optimized search terms
from user queries using LLM.
"""

import re
from typing import List, Dict, Any, Optional
from datetime import datetime

from genai_search.core.utils.logging_config import LoggedClass, log_execution_time
from genai_search.core.utils.models import SearchTerms, SearchTermsOutput, ComponentConfig
from genai_search.core.utils.prompts import (
    SEARCH_TERMS_SYSTEM_PROMPT,
    SEARCH_TERMS_HUMAN_PROMPT,
    PROMPT_TEMPLATES,
    FALLBACK_PROMPTS
)
from genai_search.core.llm_manager import LLMManager

class SearchTermGenerator(LoggedClass):
    """Generates optimized search terms from user queries"""
    
    def __init__(self, 
                 llm_manager: LLMManager,
                 config: Optional[ComponentConfig] = None):
        super().__init__("SearchTermGenerator")
        self.llm_manager = llm_manager
        self.config = config or ComponentConfig()
        self.logger.info("Search Term Generator initialized")
    
    @log_execution_time
    def generate_search_terms(self, 
                           user_query: str, 
                           query_type: str = "general",
                           max_terms: int = 10) -> SearchTerms:
        self.logger.info(f"Generating search terms for query: '{user_query}'")
        try:
            system_prompt, human_prompt = self._get_prompts(query_type)
            result = self.llm_manager.generate_text(
                system_prompt=system_prompt,
                human_prompt=human_prompt,
                inputs={"query": user_query}
            )
            search_terms = self._parse_search_terms(result, max_terms)
            confidence_scores = self._calculate_confidence_scores(search_terms, user_query)
            return SearchTerms(
                original_query=user_query,
                terms=search_terms,
                confidence_scores=confidence_scores,
                generation_time=datetime.now()
            )
        except Exception as e:
            self.logger.error(f"Failed to generate search terms: {e}")
            return self._fallback_search_terms(user_query, max_terms)
    
    def _get_prompts(self, query_type: str) -> tuple[str, str]:
        if query_type in PROMPT_TEMPLATES:
            template = PROMPT_TEMPLATES[query_type]["search_terms"]
            return SEARCH_TERMS_SYSTEM_PROMPT, template
        return SEARCH_TERMS_SYSTEM_PROMPT, SEARCH_TERMS_HUMAN_PROMPT
    
    def _parse_search_terms(self, llm_result: str, max_terms: int) -> List[str]:
        terms = []
        lines = llm_result.strip().split('\n')
        for line in lines:
            line = re.sub(r'^\d+\.\s*', '', line.strip())
            line = re.sub(r'^[-*]\s*', '', line)
            if line and len(line) > 2:
                terms.append(line)
        terms = terms[:max_terms]
        seen, unique_terms = set(), []
        for term in terms:
            if term.lower() not in seen:
                unique_terms.append(term)
                seen.add(term.lower())
        return unique_terms
    
    def _calculate_confidence_scores(self, search_terms: List[str], original_query: str) -> List[float]:
        scores = []
        query_words = set(original_query.lower().split())
        for term in search_terms:
            term_words = set(term.lower().split())
            overlap = len(query_words.intersection(term_words))
            total_words = len(query_words.union(term_words))
            score = (overlap / total_words) if total_words > 0 else 0.5
            if len(term.split()) > 2:
                score *= 1.2
            scores.append(min(score, 1.0))
        return scores
    
    def _fallback_search_terms(self, user_query: str, max_terms: int) -> SearchTerms:
        self.logger.warning("Using fallback search term generation")
        words = user_query.lower().split()
        stop_words = {'the','a','an','and','or','but','in','on','at','to','for','of','with','by','is','are','was','were','be','been','being','have','has','had','do','does','did','will','would','could','should','may','might','can','this','that','these','those'}
        keywords = [w for w in words if w not in stop_words and len(w) > 2]
        terms = []
        for i in range(len(keywords)):
            if i + 1 < len(keywords):
                terms.append(f"{keywords[i]} {keywords[i+1]}")
            terms.append(keywords[i])
        terms = terms[:max_terms-1]
        if user_query not in terms:
            terms.insert(0, user_query)
        terms = terms[:max_terms]
        confidence_scores = [0.8] * len(terms)
        return SearchTerms(
            original_query=user_query,
            terms=terms,
            confidence_scores=confidence_scores,
            generation_time=datetime.now()
        ) 