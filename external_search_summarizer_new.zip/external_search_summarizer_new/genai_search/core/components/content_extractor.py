"""
Content Extractor Component (organized package)
"""

import re
import time
from typing import List, Optional
from datetime import datetime
from urllib.parse import urlparse
from bs4 import BeautifulSoup
import requests

from genai_search.core.utils.logging_config import LoggedClass, log_execution_time
from genai_search.core.utils.models import SearchResult, ExtractedContent, ContentType, ComponentConfig

try:
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.common.exceptions import TimeoutException
    SELENIUM_AVAILABLE = True
except ImportError:
    SELENIUM_AVAILABLE = False

class ContentExtractor(LoggedClass):
    """Extracts content from web pages using Selenium and BeautifulSoup"""
    
    def __init__(self, config: Optional[ComponentConfig] = None):
        super().__init__("ContentExtractor")
        self.config = config or ComponentConfig()
        self.driver = None
        
        self.main_content_selectors = [
            'main', 'article', '[role="main"]', '.content', '.post-content',
            '.entry-content', '.article-content', '#content', '#main'
        ]
        
        self.remove_elements = [
            'script', 'style', 'nav', 'header', 'footer', '.sidebar',
            '.advertisement', '.social-share', '.ads', '.comments'
        ]
        
        if SELENIUM_AVAILABLE:
            self._initialize_selenium()
        
        self.logger.info("Content Extractor initialized")
    
    def _initialize_selenium(self) -> None:
        try:
            chrome_options = Options()
            if self.config.headless_browser:
                chrome_options.add_argument("--headless")
            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--disable-dev-shm-usage")
            chrome_options.add_argument("--disable-gpu")
            chrome_options.add_argument("--window-size=1920,1080")
            chrome_options.add_argument("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
            chrome_options.add_argument("--disable-extensions")
            chrome_options.add_argument("--disable-plugins")
            chrome_options.add_argument("--disable-images")
            
            self.driver = webdriver.Chrome(options=chrome_options)
            self.driver.set_page_load_timeout(self.config.page_load_timeout)
            self.logger.info("Selenium WebDriver initialized successfully")
        except Exception as e:
            self.logger.error(f"Failed to initialize Selenium WebDriver: {e}")
            self.driver = None
    
    @log_execution_time
    def extract_content(self, search_results: List[SearchResult]) -> List[ExtractedContent]:
        self.logger.info(f"Extracting content from {len(search_results)} URLs")
        extracted_contents = []
        
        for i, result in enumerate(search_results):
            self.logger.debug(f"Extracting content {i+1}/{len(search_results)}: {result.url}")
            try:
                content = self._extract_single_content(result)
                if content:
                    extracted_contents.append(content)
                if i < len(search_results) - 1:
                    time.sleep(0.5)
            except Exception as e:
                self.logger.error(f"Failed to extract content from {result.url}: {e}")
                continue
        
        self.logger.info(f"Successfully extracted content from {len(extracted_contents)} URLs")
        return extracted_contents
    
    def _extract_single_content(self, search_result: SearchResult) -> Optional[ExtractedContent]:
        try:
            if self.driver:
                content = self._extract_with_selenium(search_result)
                if content:
                    return content
            return self._extract_with_requests(search_result)
        except Exception as e:
            self.logger.error(f"Content extraction failed for {search_result.url}: {e}")
            return None
    
    def _extract_with_selenium(self, search_result: SearchResult) -> Optional[ExtractedContent]:
        try:
            self.driver.get(search_result.url)
            WebDriverWait(self.driver, self.config.page_load_timeout).until(
                EC.presence_of_element_located((By.TAG_NAME, "body"))
            )
            page_source = self.driver.page_source
            soup = BeautifulSoup(page_source, 'html.parser')
            title, content = self._parse_content(soup)
            
            if not content or len(content.strip()) < 50:
                return None
            
            return ExtractedContent(
                url=search_result.url,
                title=title or search_result.title,
                content=content,
                relevance_score=0.0,
                word_count=len(content.split()),
                content_type=self._detect_content_type(content, search_result.url),
                extraction_time=datetime.now(),
                metadata={
                    "extraction_method": "selenium",
                    "original_title": search_result.title,
                    "original_snippet": search_result.snippet
                }
            )
        except Exception as e:
            self.logger.error(f"Selenium extraction failed for {search_result.url}: {e}")
            return None
    
    def _extract_with_requests(self, search_result: SearchResult) -> Optional[ExtractedContent]:
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            }
            
            response = requests.get(search_result.url, headers=headers, timeout=self.config.page_load_timeout)
            response.raise_for_status()
            soup = BeautifulSoup(response.content, 'html.parser')
            title, content = self._parse_content(soup)
            
            if not content or len(content.strip()) < 50:
                return None
            
            return ExtractedContent(
                url=search_result.url,
                title=title or search_result.title,
                content=content,
                relevance_score=0.0,
                word_count=len(content.split()),
                content_type=self._detect_content_type(content, search_result.url),
                extraction_time=datetime.now(),
                metadata={
                    "extraction_method": "requests",
                    "response_status": response.status_code,
                    "original_title": search_result.title,
                    "original_snippet": search_result.snippet
                }
            )
        except Exception as e:
            self.logger.error(f"Requests extraction failed for {search_result.url}: {e}")
            return None
    
    def _parse_content(self, soup: BeautifulSoup) -> tuple[Optional[str], str]:
        title = None
        title_tag = soup.find('title')
        if title_tag:
            title = title_tag.get_text().strip()
        
        # Remove unwanted elements
        for element in self.remove_elements:
            for tag in soup.find_all(element):
                tag.decompose()
        
        # Try multiple strategies to find main content
        content = ""
        
        # Strategy 1: Look for main content selectors
        for selector in self.main_content_selectors:
            main_content = soup.select_one(selector)
            if main_content:
                content = main_content.get_text(separator=' ', strip=True)
                if len(content) > 200:  # Ensure substantial content
                    break
        
        # Strategy 2: Look for content in common blog/article structures
        if not content or len(content) < 200:
            content_selectors = [
                '.blog-content', '.post-body', '.entry-body', '.content-body',
                '.article-body', '.post-text', '.entry-text', '.content-text',
                '.elementor-widget-theme-post-content', '.elementor-post__content'
            ]
            for selector in content_selectors:
                element = soup.select_one(selector)
                if element:
                    content = element.get_text(separator=' ', strip=True)
                    if len(content) > 200:
                        break
        
        # Strategy 3: Look for divs with substantial content
        if not content or len(content) < 200:
            divs = soup.find_all('div')
            for div in divs:
                text = div.get_text(separator=' ', strip=True)
                if 300 < len(text) < 10000:  # Look for substantial but not excessive content
                    # Check if it contains meaningful content (not just navigation)
                    if any(keyword in text.lower() for keyword in ['artificial intelligence', 'ai', 'machine learning', 'trends', 'technology']):
                        content = text
                        break
        
        # Strategy 4: Fallback to body if no substantial content found
        if not content or len(content) < 200:
            body = soup.find('body')
            if body:
                content = body.get_text(separator=' ', strip=True)
        
        content = self._clean_content(content)
        
        # Validate content quality
        if len(content) < 100:
            self.logger.warning(f"Extracted content too short: {len(content)} characters")
            return title, ""
        
        return title, content
    
    def _clean_content(self, content: str) -> str:
        content = re.sub(r'\s+', ' ', content)
        content = re.sub(r'Cookie Policy|Privacy Policy|Terms of Service|Contact Us', '', content)
        content = re.sub(r'Subscribe|Newsletter|Sign up|Login|Register', '', content)
        
        if len(content) > self.config.max_content_length:
            content = content[:self.config.max_content_length]
        
        return content.strip()
    
    def _detect_content_type(self, content: str, url: str) -> ContentType:
        url_lower = url.lower()
        content_lower = content.lower()
        
        if any(word in url_lower for word in ['news', 'article', 'story']):
            return ContentType.NEWS
        if any(word in url_lower for word in ['blog', 'post']):
            return ContentType.BLOG
        if any(word in content_lower for word in ['abstract', 'methodology', 'conclusion', 'references']):
            return ContentType.ACADEMIC
        if any(word in url_lower for word in ['docs', 'documentation', 'api', 'guide']):
            return ContentType.DOCUMENTATION
        
        return ContentType.ARTICLE
    
    def close(self) -> None:
        if self.driver:
            try:
                self.driver.quit()
                self.logger.info("Selenium WebDriver closed")
            except Exception as e:
                self.logger.error(f"Error closing WebDriver: {e}") 