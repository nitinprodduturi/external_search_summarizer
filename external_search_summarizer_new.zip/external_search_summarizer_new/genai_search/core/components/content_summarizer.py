"""
Content Summarizer Component (organized package)

Enhanced version that includes source citations in summaries.
"""

from typing import List, Optional, Dict, Any
import re

from genai_search.core.utils.logging_config import LoggedClass, log_execution_time
from genai_search.core.utils.models import ExtractedContent, ComponentConfig
from genai_search.core.utils.prompts import (
    SUMMARIZATION_SYSTEM_PROMPT,
    SUMMARIZATION_HUMAN_PROMPT,
    PROMPT_TEMPLATES,
    CITATION_SUMMARIZATION_SYSTEM_PROMPT,
    CITATION_SUMMARIZATION_HUMAN_PROMPT,
)
from genai_search.core.llm_manager import LLMManager

class ContentSummarizer(LoggedClass):
    """Summarizes relevant content using LLM with source citations"""
    
    def __init__(self, 
                 llm_manager: LLMManager,
                 config: Optional[ComponentConfig] = None):
        super().__init__("ContentSummarizer")
        self.llm_manager = llm_manager
        self.config = config or ComponentConfig()
        self.logger.info("Enhanced Content Summarizer initialized")
    
    @log_execution_time
    def summarize_content(self, 
                         user_query: str,
                         relevant_contents: List[ExtractedContent],
                         relevance_threshold: float = 0.7,
                         query_type: str = "general",
                         max_summary_length: int = 2000,
                         include_citations: bool = True) -> str:
        self.logger.info(f"Summarizing {len(relevant_contents)} content pieces with citations: {include_citations}")
        
        if not relevant_contents:
            return "No relevant content found to summarize."
        
        filtered_contents = [
            content for content in relevant_contents 
            if content.relevance_score >= relevance_threshold
        ]
        
        if not filtered_contents:
            return f"No content met the relevance threshold ({relevance_threshold}) for summarization."
        
        try:
            if include_citations:
                summary = self._generate_cited_summary(user_query, filtered_contents, query_type, max_summary_length)
            else:
                summary = self._generate_standard_summary(user_query, filtered_contents, query_type, max_summary_length)
            
            self.logger.info(f"Generated summary with {len(summary)} characters")
            return summary
        except Exception as e:
            self.logger.error(f"Failed to generate summary: {e}")
            return self._fallback_summarization(user_query, filtered_contents, include_citations)
    
    def _generate_cited_summary(self, 
                               user_query: str, 
                               contents: List[ExtractedContent], 
                               query_type: str,
                               max_length: int) -> str:
        """Generate summary with inline source citations."""
        try:
            # Use citation-specific prompts
            system_prompt = CITATION_SUMMARIZATION_SYSTEM_PROMPT
            human_prompt = CITATION_SUMMARIZATION_HUMAN_PROMPT
            
            # Prepare content with source information
            content_text = self._prepare_content_for_citation_summarization(contents)
            
            summary = self.llm_manager.generate_text(
                system_prompt=system_prompt,
                human_prompt=human_prompt,
                inputs={
                    "query": user_query,
                    "content": content_text,
                    "max_length": max_length
                }
            )
            
            # Clean and format the summary
            summary = self._clean_cited_summary(summary, max_length)
            
            # Add source reference table if not already included
            if not self._has_source_references(summary):
                summary = self._add_source_reference_table(summary, contents)
            
            return summary
            
        except Exception as e:
            self.logger.error(f"Citation summarization failed: {e}")
            return self._fallback_cited_summarization(user_query, contents)
    
    def _generate_standard_summary(self, 
                                  user_query: str, 
                                  contents: List[ExtractedContent], 
                                  query_type: str,
                                  max_length: int) -> str:
        """Generate standard summary without citations."""
        system_prompt, human_prompt = self._get_prompts(query_type)
        content_text = self._prepare_content_for_summarization(contents)
        
        summary = self.llm_manager.generate_text(
            system_prompt=system_prompt,
            human_prompt=human_prompt,
            inputs={
                "query": user_query,
                "content": content_text
            }
        )
        
        return self._clean_summary(summary, max_length)
    
    def _prepare_content_for_citation_summarization(self, contents: List[ExtractedContent]) -> str:
        """Prepare content with clear source identification for citation summarization."""
        content_text = ""
        for i, content in enumerate(contents, 1):
            content_text += f"\n=== SOURCE {i} ===\n"
            content_text += f"Title: {content.title}\n"
            content_text += f"URL: {content.url}\n"
            content_text += f"Relevance Score: {content.relevance_score:.2f}\n"
            content_text += f"Content Type: {content.content_type.value}\n"
            content_text += f"Word Count: {content.word_count}\n"
            content_text += f"Content:\n{content.content}\n"
            content_text += f"=== END SOURCE {i} ===\n"
        return content_text
    
    def _prepare_content_for_summarization(self, contents: List[ExtractedContent]) -> str:
        """Prepare content for standard summarization."""
        content_text = ""
        for i, content in enumerate(contents, 1):
            content_text += f"\n--- Source {i}: {content.title} ---\n"
            content_text += f"URL: {content.url}\n"
            content_text += f"Relevance Score: {content.relevance_score:.2f}\n"
            content_text += f"Content Type: {content.content_type.value}\n"
            content_text += f"Word Count: {content.word_count}\n"
            content_text += f"Content: {content.content}\n"
        return content_text
    
    def _clean_cited_summary(self, summary: str, max_length: int) -> str:
        """Clean and format cited summary to ensure clean markdown output."""
        # Remove any introductory text or meta-commentary
        summary = self._remove_meta_text(summary)
        
        # Remove extra whitespace but preserve markdown formatting
        summary = self._clean_markdown_whitespace(summary)
        
        # Ensure proper citation format
        summary = self._standardize_citations(summary)
        
        # Truncate if too long
        if len(summary) > max_length:
            summary = self._truncate_at_sentence_boundary(summary, max_length)
        
        return summary.strip()
    
    def _remove_meta_text(self, summary: str) -> str:
        """Remove any introductory text, explanations, or meta-commentary."""
        # Common patterns to remove
        patterns_to_remove = [
            r"^Based on \d+ sources?,? here's what I found about.*?:?\n*",
            r"^Here's a comprehensive summary.*?:?\n*",
            r"^The following summary.*?:?\n*",
            r"^Based on the provided sources.*?:?\n*",
            r"^Here's what I found.*?:?\n*",
            r"^Summary:?\n*",
            r"^Executive Summary:?\n*",
            r"^Key Findings:?\n*",
            r"^Conclusion:?\n*",
            r"^In conclusion.*?\n*",
            r"^Overall.*?\n*",
            r"^To summarize.*?\n*",
            r"^This summary.*?\n*",
            r"^The summary.*?\n*",
            r"^Sources consulted.*?\n*",
            r"^Total sources.*?\n*",
            r"^Average relevance.*?\n*",
            r"^--- SOURCE REFERENCES ---.*",
            r"^Source References:?\n*",
            r"^References:?\n*",
            r"^Sources:?\n*",
        ]
        
        cleaned_summary = summary
        for pattern in patterns_to_remove:
            cleaned_summary = re.sub(pattern, "", cleaned_summary, flags=re.IGNORECASE | re.MULTILINE)
        
        return cleaned_summary.strip()
    
    def _clean_markdown_whitespace(self, summary: str) -> str:
        """Clean whitespace while preserving markdown formatting."""
        # Split into lines to preserve markdown structure
        lines = summary.split('\n')
        cleaned_lines = []
        
        for line in lines:
            # Preserve markdown headers and lists
            if re.match(r'^#{1,6}\s', line) or re.match(r'^[\*\-\+]\s', line) or re.match(r'^\d+\.\s', line):
                cleaned_lines.append(line.strip())
            else:
                # For regular text, clean extra whitespace
                cleaned_line = ' '.join(line.split())
                if cleaned_line:
                    cleaned_lines.append(cleaned_line)
        
        return '\n'.join(cleaned_lines)
    
    def _truncate_at_sentence_boundary(self, summary: str, max_length: int) -> str:
        """Truncate summary at sentence boundary to avoid cutting mid-sentence."""
        # Try to truncate at a sentence boundary
        sentences = summary.split('. ')
        truncated = ""
        
        for sentence in sentences:
            if len(truncated + sentence + '. ') <= max_length:
                truncated += sentence + '. '
            else:
                break
        
        summary = truncated.strip()
        if not summary.endswith('.'):
            summary += '...'
        
        return summary
    
    def _standardize_citations(self, summary: str) -> str:
        """Standardize citation format in the summary."""
        # Look for various citation patterns and standardize them
        patterns = [
            r'\[(\d+)\]',           # [1], [2], etc.
            r'\((\d+)\)',           # (1), (2), etc.
            r'Source (\d+)',        # Source 1, Source 2, etc.
            r'Ref (\d+)',           # Ref 1, Ref 2, etc.
        ]
        
        for pattern in patterns:
            summary = re.sub(pattern, r'[Source \1]', summary)
        
        return summary
    
    def _has_source_references(self, summary: str) -> bool:
        """Check if summary already has source references."""
        # Look for common source reference patterns
        patterns = [
            r'Source \d+:',         # Source 1:, Source 2:, etc.
            r'References?:',         # Reference: or References:
            r'Sources?:',            # Source: or Sources:
            r'\[Source \d+\]',      # [Source 1], [Source 2], etc.
        ]
        
        return any(re.search(pattern, summary, re.IGNORECASE) for pattern in patterns)
    
    def _add_source_reference_table(self, summary: str, contents: List[ExtractedContent]) -> str:
        """Add a source reference table to the summary."""
        reference_table = "\n\n--- SOURCE REFERENCES ---\n"
        
        for i, content in enumerate(contents, 1):
            reference_table += f"[Source {i}] {content.title}\n"
            reference_table += f"    URL: {content.url}\n"
            reference_table += f"    Relevance: {content.relevance_score:.2f}\n"
            reference_table += f"    Type: {content.content_type.value}\n\n"
        
        return summary + reference_table
    
    def _clean_summary(self, summary: str, max_length: int) -> str:
        """Clean standard summary."""
        summary = " ".join(summary.split())
        if len(summary) > max_length:
            summary = summary[:max_length].rsplit(' ', 1)[0] + "..."
        return summary.strip()
    
    def _get_prompts(self, query_type: str) -> tuple[str, str]:
        """Get appropriate prompts for the query type."""
        if query_type in PROMPT_TEMPLATES:
            template = PROMPT_TEMPLATES[query_type]["summary"]
            return SUMMARIZATION_SYSTEM_PROMPT, template
        return SUMMARIZATION_SYSTEM_PROMPT, SUMMARIZATION_HUMAN_PROMPT
    
    def _fallback_summarization(self, user_query: str, contents: List[ExtractedContent], include_citations: bool = True) -> str:
        """Fallback summarization when LLM fails."""
        self.logger.warning("Using fallback summarization")
        try:
            if include_citations:
                return self._fallback_cited_summarization(user_query, contents)
            else:
                return self._fallback_standard_summarization(user_query, contents)
        except Exception as e:
            self.logger.error(f"Fallback summarization failed: {e}")
            return f"Error generating summary: {str(e)}"
    
    def _fallback_cited_summarization(self, user_query: str, contents: List[ExtractedContent]) -> str:
        """Fallback cited summarization with clean markdown output."""
        sorted_contents = sorted(contents, key=lambda x: x.relevance_score, reverse=True)
        top_contents = sorted_contents[:3]
        
        # Create clean markdown summary without introductory text
        summary_parts = []
        
        # Main content sections
        for i, content in enumerate(top_contents, 1):
            sentences = content.content.split('.')
            key_sentences = sentences[:3]
            summary_parts.append(f"## Key Insights from [Source {i}]\n")
            summary_parts.append(f"**{content.title}**\n")
            summary_parts.append(" ".join(key_sentences) + ".\n")
        
        # Add source reference table
        reference_table = self._add_source_reference_table("", contents)
        
        return "".join(summary_parts) + reference_table
    
    def _fallback_standard_summarization(self, user_query: str, contents: List[ExtractedContent]) -> str:
        """Fallback standard summarization with clean markdown output."""
        sorted_contents = sorted(contents, key=lambda x: x.relevance_score, reverse=True)
        top_contents = sorted_contents[:3]
        
        # Create clean markdown summary without introductory text
        summary_parts = []
        
        # Main content sections
        for i, content in enumerate(top_contents, 1):
            sentences = content.content.split('.')
            key_sentences = sentences[:3]
            summary_parts.append(f"## Key Insights from Source {i}\n")
            summary_parts.append(f"**{content.title}**\n")
            summary_parts.append(" ".join(key_sentences) + ".\n")
        
        return "".join(summary_parts) 