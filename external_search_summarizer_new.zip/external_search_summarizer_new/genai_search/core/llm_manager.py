"""
LLM Manager (organized package)
"""

import os
from typing import Optional, Dict, Any
from langchain.schema import BaseOutputParser
from langchain.schema.output_parser import StrOutputParser
from langchain.chains import LLMChain
from langchain.prompts.chat import ChatPromptTemplate

from genai_search.core.utils.logging_config import LoggedClass
from genai_search.core.utils.models import LLMProvider, ComponentConfig

try:
    import google.generativeai as genai
    from langchain_google_genai import ChatGoogleGenerativeAI
    GOOGLE_AI_AVAILABLE = True
except ImportError:
    GOOGLE_AI_AVAILABLE = False

try:
    from langchain_openai import AzureChatOpenAI
    AZURE_OPENAI_AVAILABLE = True
except ImportError:
    AZURE_OPENAI_AVAILABLE = False

class LLMManager(LoggedClass):
    def __init__(self, 
                 provider: LLMProvider = LLMProvider.GOOGLE,
                 config: Optional[ComponentConfig] = None):
        super().__init__("LLMManager")
        self.provider = provider
        self.config = config or ComponentConfig()
        self.llm = None
        self.parser = StrOutputParser()
        self.logger.info(f"Initializing LLM Manager with provider: {provider}")
        self._initialize_llm()
    
    def _initialize_llm(self) -> None:
        try:
            if self.provider == LLMProvider.GOOGLE:
                self._initialize_google_llm()
            elif self.provider == LLMProvider.AZURE:
                self._initialize_azure_llm()
            else:
                raise ValueError(f"Unsupported LLM provider: {self.provider}")
            self.logger.info(f"LLM initialized successfully with provider: {self.provider}")
        except Exception as e:
            self.logger.error(f"Failed to initialize LLM: {e}")
            raise
    
    def _initialize_google_llm(self) -> None:
        if not GOOGLE_AI_AVAILABLE:
            raise ImportError("Google Generative AI not available. Install google-generativeai langchain-google-genai")
        api_key = os.getenv("GOOGLE_API_KEY")
        if not api_key:
            raise ValueError("Google API key is required. Set GOOGLE_API_KEY env var")
        genai.configure(api_key=api_key)
        self.llm = ChatGoogleGenerativeAI(
            model="gemini-2.0-flash",
            temperature=self.config.llm_temperature,
            max_output_tokens=self.config.llm_max_tokens
        )
        self.logger.debug("Google Generative AI initialized")
    
    def _initialize_azure_llm(self) -> None:
        if not AZURE_OPENAI_AVAILABLE:
            raise ImportError("Azure OpenAI not available. Install langchain-openai")
        api_key = os.getenv("AZURE_OPENAI_API_KEY")
        endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
        deployment_name = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
        if not all([api_key, endpoint, deployment_name]):
            raise ValueError("Missing Azure OpenAI credentials")
        self.llm = AzureChatOpenAI(
            azure_deployment=deployment_name,
            openai_api_version="2023-12-01-preview",
            temperature=self.config.llm_temperature,
            max_tokens=self.config.llm_max_tokens
        )
        self.logger.debug("Azure OpenAI initialized")
    
    def create_chain(self, system_prompt: str, human_prompt: str, output_parser: Optional[BaseOutputParser] = None) -> LLMChain:
        prompt = ChatPromptTemplate.from_messages([("system", system_prompt),("human", human_prompt)])
        parser = output_parser or self.parser
        return prompt | self.llm | parser
    
    def invoke_chain(self, chain: LLMChain, inputs: Dict[str, Any], max_retries: int = 3) -> Any:
        for attempt in range(max_retries):
            try:
                return chain.invoke(inputs)
            except Exception as e:
                self.logger.warning(f"LLM chain invocation failed (attempt {attempt+1}): {e}")
                if attempt == max_retries - 1:
                    raise
                import time; time.sleep(2 ** attempt)
    
    def generate_text(self, system_prompt: str, human_prompt: str, inputs: Dict[str, Any], output_parser: Optional[BaseOutputParser] = None) -> Any:
        chain = self.create_chain(system_prompt, human_prompt, output_parser)
        return self.invoke_chain(chain, inputs)
    
    def get_available_providers(self) -> Dict[str, bool]:
        return {"google": GOOGLE_AI_AVAILABLE, "azure": AZURE_OPENAI_AVAILABLE}
    
    def switch_provider(self, provider: LLMProvider) -> None:
        self.logger.info(f"Switching LLM provider from {self.provider} to {provider}")
        old = self.provider
        self.provider = provider
        try:
            self._initialize_llm()
        except Exception:
            self.provider = old
            raise
    
    def get_model_info(self) -> Dict[str, Any]:
        info = {
            "provider": self.provider.value,
            "temperature": self.config.llm_temperature,
            "max_tokens": self.config.llm_max_tokens,
            "available_providers": self.get_available_providers()
        }
        info["model"] = "gemini-2.0-flash" if self.provider == LLMProvider.GOOGLE else "gpt-4"
        return info 