"""
Main Orchestrator for the GenAI Search Component (organized package)
"""

import time
from typing import Dict, Any, Optional
from datetime import datetime
from dotenv import load_dotenv

from genai_search.core.utils.logging_config import LoggedClass, log_execution_time, setup_logging
from genai_search.core.utils.models import (
    LLMProvider, SearchEngine, ComponentConfig, 
    SearchResponse, ProcessingStats, ErrorInfo, SearchSession, SearchTermsOutput
)
from genai_search.core.llm_manager import LLMManager
from genai_search.core.components import (
    SearchTermGenerator,
    WebSearchEngine,
    ContentExtractor,
    RelevanceScorer,
    ContentSummarizer,
)

# Load environment variables
load_dotenv()

class GenAISearchOrchestrator(LoggedClass):
    def __init__(self, 
                 llm_provider: LLMProvider = LLMProvider.GOOGLE,
                 search_engine: SearchEngine = SearchEngine.GOOGLE,
                 config: Optional[ComponentConfig] = None):
        super().__init__("GenAISearchOrchestrator")
        self.config = config or ComponentConfig()
        self.llm_provider = llm_provider
        self.search_engine = search_engine
        self._initialize_components()
        self.logger.info("GenAI Search Orchestrator initialized successfully")
    
    def _initialize_components(self) -> None:
        try:
            self.llm_manager = LLMManager(provider=self.llm_provider, config=self.config)
            self.search_term_generator = SearchTermGenerator(llm_manager=self.llm_manager, config=self.config)
            self.web_search_engine = WebSearchEngine(search_engine=self.search_engine, config=self.config)
            self.content_extractor = ContentExtractor(config=self.config)
            self.relevance_scorer = RelevanceScorer(llm_manager=self.llm_manager, config=self.config)
            self.content_summarizer = ContentSummarizer(llm_manager=self.llm_manager, config=self.config)
            self.logger.info("All components initialized successfully")
        except Exception as e:
            self.logger.error(f"Failed to initialize components: {e}")
            raise
    
    @log_execution_time
    def process_query(self, 
                      user_query: str,
                      query_type: str = "general",
                      max_results: int = 10,
                      relevance_threshold: float = 0.7,
                      include_news: bool = False,
                      include_academic: bool = False) -> SearchResponse:
        start_time = time.time()
        session_id = f"session_{int(start_time)}"
        self.logger.info(f"Starting query processing: '{user_query}'")
        self.logger.info(f"Session ID: {session_id}")
        session = SearchSession(session_id=session_id, user_query=user_query, start_time=datetime.now(), config=self.config)
        try:
            search_terms = self.search_term_generator.generate_search_terms(user_query, query_type, 10)
            search_results = self.web_search_engine.search(
                search_terms.terms,
                max_results_per_term=max_results // max(1, len(search_terms.terms)),
                include_news=include_news,
                include_academic=include_academic
            )
            extracted_contents = self.content_extractor.extract_content(search_results)
            scored_contents = self.relevance_scorer.calculate_relevance_scores(user_query, extracted_contents)
            summary = self.content_summarizer.summarize_content(
                user_query, 
                scored_contents, 
                relevance_threshold,
                query_type=query_type,
                include_citations=True  # Enable source citations
            )
            processing_time = time.time() - start_time
            stats = self._calculate_statistics(search_results, extracted_contents, scored_contents, processing_time)
            try:
                search_terms_output = SearchTermsOutput(
                    search_terms=search_terms.terms,
                    confidence_scores=getattr(search_terms, 'confidence_scores', []),
                    reasoning="LLM-generated search terms"
                )
            except Exception:
                search_terms_output = None
            response = SearchResponse(
                user_query=user_query,
                search_terms=search_terms_output,
                search_results=[self._result_to_dict(r) for r in search_results],
                extracted_contents=[self._content_to_dict(c) for c in scored_contents],
                summary=summary,
                statistics=stats,
                processing_time=processing_time
            )
            session.end_time = datetime.now()
            session.status = "completed"
            session.results = response
            self.logger.info(f"Query processing completed successfully in {processing_time:.2f} seconds")
            return response
        except Exception as e:
            self.logger.error(f"Query processing failed: {e}")
            error_info = ErrorInfo(
                error_type=type(e).__name__,
                error_message=str(e),
                component="orchestrator",
                context={"user_query": user_query}
            )
            session.errors.append(error_info)
            session.status = "failed"
            session.end_time = datetime.now()
            return self._create_error_response(user_query, str(e), time.time() - start_time)
    
    def _calculate_statistics(self, 
                              search_results, 
                              extracted_contents, 
                              scored_contents, 
                              processing_time) -> ProcessingStats:
        relevant_contents = [c for c in scored_contents if c.relevance_score >= self.config.relevance_threshold]
        avg_relevance = sum(c.relevance_score for c in scored_contents) / len(scored_contents) if scored_contents else 0
        return ProcessingStats(
            total_search_results=len(search_results),
            total_extracted_contents=len(extracted_contents),
            relevant_contents=len(relevant_contents),
            average_relevance_score=avg_relevance,
            processing_time=processing_time
        )
    
    def _result_to_dict(self, result) -> Dict[str, Any]:
        return {
            "title": result.title,
            "url": result.url,
            "snippet": result.snippet,
            "relevance_score": result.relevance_score,
            "source": result.source,
            "timestamp": result.timestamp.isoformat() if result.timestamp else None,
            "metadata": result.metadata
        }
    
    def _content_to_dict(self, content) -> Dict[str, Any]:
        return {
            "url": content.url,
            "title": content.title,
            "content": content.content,
            "relevance_score": content.relevance_score,
            "word_count": content.word_count,
            "content_type": content.content_type.value,
            "extraction_time": content.extraction_time.isoformat() if content.extraction_time else None,
            "metadata": content.metadata
        }
    
    def _create_error_response(self, user_query: str, error_message: str, processing_time: float) -> SearchResponse:
        return SearchResponse(
            user_query=user_query,
            search_terms=None,
            search_results=[],
            extracted_contents=[],
            summary=f"Error processing query: {error_message}",
            statistics=ProcessingStats(),
            processing_time=processing_time
        )
    
    def close(self) -> None:
        """Clean up resources and close components that need explicit cleanup."""
        try:
            if hasattr(self, 'content_extractor'):
                self.content_extractor.close()
                self.logger.info("Content extractor closed successfully")
        except Exception as e:
            self.logger.error(f"Error during cleanup: {e}")


def create_genai_component(llm_provider: str = "google",
                          search_engine: str = "google",
                          **kwargs) -> GenAISearchOrchestrator:
    setup_logging()
    llm_provider_enum = LLMProvider(llm_provider.lower())
    search_engine_enum = SearchEngine(search_engine.lower())
    config = ComponentConfig(**kwargs)
    return GenAISearchOrchestrator(
        llm_provider=llm_provider_enum,
        search_engine=search_engine_enum,
        config=config
    ) 