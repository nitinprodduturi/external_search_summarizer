"""
Logging configuration for the GenAI Search Component

This module provides centralized logging configuration and utilities
for all components of the system.
"""

import os
import logging
import logging.handlers
from datetime import datetime
from pathlib import Path
from typing import Optional

class LoggerConfig:
    """Centralized logging configuration for the GenAI Search Component"""
    
    def __init__(self, 
                 log_level: str = "INFO",
                 log_file: Optional[str] = None,
                 log_format: Optional[str] = None,
                 max_file_size: int = 10 * 1024 * 1024,  # 10MB
                 backup_count: int = 5):
        """
        Initialize logging configuration
        
        Args:
            log_level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
            log_file: Path to log file (optional)
            log_format: Custom log format (optional)
            max_file_size: Maximum size of log file before rotation
            backup_count: Number of backup files to keep
        """
        self.log_level = getattr(logging, log_level.upper(), logging.INFO)
        self.log_file = log_file
        self.log_format = log_format or "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        self.max_file_size = max_file_size
        self.backup_count = backup_count
        
        # Create logs directory if it doesn't exist
        if self.log_file:
            log_path = Path(self.log_file)
            log_path.parent.mkdir(parents=True, exist_ok=True)
    
    def setup_logger(self, name: str) -> logging.Logger:
        """
        Set up a logger with the specified configuration
        
        Args:
            name: Logger name (usually module name)
            
        Returns:
            Configured logger instance
        """
        logger = logging.getLogger(name)
        
        # Avoid adding handlers multiple times
        if logger.handlers:
            return logger
        
        logger.setLevel(self.log_level)
        
        # Create formatter
        formatter = logging.Formatter(self.log_format)
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(self.log_level)
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
        
        # File handler (if log_file is specified)
        if self.log_file:
            try:
                file_handler = logging.handlers.RotatingFileHandler(
                    self.log_file,
                    maxBytes=self.max_file_size,
                    backupCount=self.backup_count
                )
                file_handler.setLevel(self.log_level)
                file_handler.setFormatter(formatter)
                logger.addHandler(file_handler)
            except Exception as e:
                logger.warning(f"Failed to set up file logging: {e}")
        
        return logger

# Global logger configuration
_logger_config = None

def get_logger(name: str) -> logging.Logger:
    """
    Get a logger instance with the global configuration
    
    Args:
        name: Logger name (usually module name)
        
    Returns:
        Configured logger instance
    """
    global _logger_config
    
    if _logger_config is None:
        # Initialize with environment variables or defaults
        log_level = os.getenv("LOG_LEVEL", "INFO")
        log_file = os.getenv("LOG_FILE", "logs/genai_search.log")
        log_format = os.getenv("LOG_FORMAT", "%(asctime)s - %(name)s - %(levelname)s - %(message)s")
        
        _logger_config = LoggerConfig(
            log_level=log_level,
            log_file=log_file,
            log_format=log_format
        )
    
    return _logger_config.setup_logger(name)

def setup_logging(log_level: str = "INFO",
                 log_file: Optional[str] = None,
                 log_format: Optional[str] = None) -> None:
    """
    Set up global logging configuration
    
    Args:
        log_level: Logging level
        log_file: Path to log file
        log_format: Custom log format
    """
    global _logger_config
    
    _logger_config = LoggerConfig(
        log_level=log_level,
        log_file=log_file,
        log_format=log_format
    )

class LoggedClass:
    """Base class for components that need logging"""
    
    def __init__(self, logger_name: Optional[str] = None):
        """
        Initialize with logging
        
        Args:
            logger_name: Name for the logger (defaults to class name)
        """
        if logger_name is None:
            logger_name = self.__class__.__name__
        
        self.logger = get_logger(logger_name)
        self.logger.debug(f"Initialized {self.__class__.__name__}")

def log_function_call(func):
    """Decorator to log function calls"""
    def wrapper(*args, **kwargs):
        logger = get_logger(func.__module__)
        logger.debug(f"Calling {func.__name__} with args={args}, kwargs={kwargs}")
        
        try:
            result = func(*args, **kwargs)
            logger.debug(f"{func.__name__} returned: {result}")
            return result
        except Exception as e:
            logger.error(f"{func.__name__} failed with error: {e}")
            raise
    
    return wrapper

def log_execution_time(func):
    """Decorator to log function execution time"""
    def wrapper(*args, **kwargs):
        logger = get_logger(func.__module__)
        start_time = datetime.now()
        
        try:
            result = func(*args, **kwargs)
            execution_time = (datetime.now() - start_time).total_seconds()
            logger.info(f"{func.__name__} executed in {execution_time:.2f} seconds")
            return result
        except Exception as e:
            execution_time = (datetime.now() - start_time).total_seconds()
            logger.error(f"{func.__name__} failed after {execution_time:.2f} seconds: {e}")
            raise
    
    return wrapper 