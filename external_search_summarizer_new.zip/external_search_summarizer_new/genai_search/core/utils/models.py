"""
Data models for the GenAI Search Component

This module contains all the data structures and models used
throughout the component for type safety and consistency.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from datetime import datetime
from enum import Enum
from pydantic import BaseModel, Field

class LLMProvider(str, Enum):
    """Supported LLM providers"""
    GOOGLE = "google"
    AZURE = "azure"

class SearchEngine(str, Enum):
    """Supported search engines"""
    GOOGLE = "google"
    BING = "bing"
    DUCKDUCKGO = "duckduckgo"

class ContentType(str, Enum):
    """Types of content"""
    ARTICLE = "article"
    NEWS = "news"
    BLOG = "blog"
    ACADEMIC = "academic"
    DOCUMENTATION = "documentation"
    OTHER = "other"

@dataclass
class SearchResult:
    """Data class for search results"""
    title: str
    url: str
    snippet: str
    relevance_score: float = 0.0
    source: str = "unknown"
    timestamp: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class ExtractedContent:
    """Data class for extracted content"""
    url: str
    title: str
    content: str
    relevance_score: float
    word_count: int
    content_type: ContentType = ContentType.OTHER
    extraction_time: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class SearchTerms:
    """Data class for generated search terms"""
    original_query: str
    terms: List[str]
    confidence_scores: List[float] = field(default_factory=list)
    generation_time: Optional[datetime] = None

@dataclass
class ProcessingStats:
    """Data class for processing statistics"""
    total_search_results: int = 0
    total_extracted_contents: int = 0
    relevant_contents: int = 0
    average_relevance_score: float = 0.0
    processing_time: float = 0.0
    search_time: float = 0.0
    extraction_time: float = 0.0
    scoring_time: float = 0.0
    summarization_time: float = 0.0

@dataclass
class SearchQuery:
    """Data class for search queries"""
    query: str
    query_type: str = "general"
    max_results: int = 10
    relevance_threshold: float = 0.7
    include_news: bool = False
    include_academic: bool = False
    language: str = "en"
    region: str = "us"

class SearchTermsOutput(BaseModel):
    """Structured output for search terms"""
    search_terms: List[str] = Field(description="List of optimized search terms for web search")
    confidence_scores: List[float] = Field(description="Confidence scores for each search term")
    reasoning: str = Field(description="Reasoning for the generated search terms")

class RelevanceScoreOutput(BaseModel):
    """Structured output for relevance scoring"""
    relevance_score: float = Field(description="Relevance score between 0 and 1")
    reasoning: str = Field(description="Reasoning for the relevance score")
    confidence: float = Field(description="Confidence in the relevance assessment")

class ContentAnalysisOutput(BaseModel):
    """Structured output for content analysis"""
    quality_score: float = Field(description="Content quality score between 0 and 1")
    content_type: ContentType = Field(description="Type of content")
    key_topics: List[str] = Field(description="Key topics identified in the content")
    summary: str = Field(description="Brief analysis of the content")

class SearchResponse(BaseModel):
    """Complete search response"""
    user_query: str
    search_terms: Optional[SearchTermsOutput] = None
    search_results: List[Dict[str, Any]]
    extracted_contents: List[Dict[str, Any]]
    summary: str
    statistics: ProcessingStats
    processing_time: float
    timestamp: datetime = Field(default_factory=datetime.now)

class ErrorInfo(BaseModel):
    """Error information"""
    error_type: str
    error_message: str
    component: str
    timestamp: datetime = Field(default_factory=datetime.now)
    context: Dict[str, Any] = Field(default_factory=dict)

class ComponentConfig(BaseModel):
    """Configuration for components"""
    max_search_results: int = 10
    max_content_length: int = 5000
    relevance_threshold: float = 0.7
    headless_browser: bool = True
    search_delay: float = 1.0
    page_load_timeout: int = 10
    llm_temperature: float = 0.3
    llm_max_tokens: int = 2048
    enable_caching: bool = False
    cache_expiration: int = 24  # hours
    max_retry_attempts: int = 3

class SearchSession(BaseModel):
    """Search session information"""
    session_id: str
    user_query: str
    start_time: datetime
    end_time: Optional[datetime] = None
    status: str = "running"  # running, completed, failed
    results: Optional[SearchResponse] = None
    errors: List[ErrorInfo] = Field(default_factory=list)
    config: ComponentConfig = Field(default_factory=ComponentConfig) 